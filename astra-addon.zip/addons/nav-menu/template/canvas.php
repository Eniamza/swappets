<?php
/**
 * Nav menu - Admin react template base.
 *
 * @since 4.0.0
 * @package Astra Addon
 */

?>
<div class="ast-mega-menu-wrap ast-offcanvas-wrapper">
	<div class="ast-mega-menu-overlay">
	</div>
	<div class="ast-mega-menu-content astra-mm-options-wrap" id="ast-mega-menu-content">

	</div>
</div>
