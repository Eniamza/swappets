<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="se-wrapper-main">
<div class="se-wrapper">
	<div class="se-wrapper-inner">
		<div class="se-icon">
			<?php echo $list_img; ?>
		</div>
		<div class="se-content">
			<?php echo $list_title . $list_sub_title . $description . $loop_button . $se_listing; ?>
		</div>
	</div>
</div>
</div>
